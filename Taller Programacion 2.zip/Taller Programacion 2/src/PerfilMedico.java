import java.time.LocalDate;
import java.time.Period;

public class PerfilMedico {

    private String primerNombre;
    private String apellido;
    private String sexo;
    private int diaNacimiento;
    private int mesNacimiento;
    private int anioNacimiento;
    private double alturaCentimetros;
    private double pesoKilogramos;

    public PerfilMedico(String primerNombre, String apellido, String sexo,
                        int diaNacimiento, int mesNacimiento, int anioNacimiento,
                        double alturaCentimetros, double pesoKilogramos) {

        this.primerNombre = primerNombre;
        this.apellido = apellido;
        this.sexo = sexo;
        this.diaNacimiento = diaNacimiento;
        this.mesNacimiento = mesNacimiento;
        this.anioNacimiento = anioNacimiento;
        setAlturaCentimetros(alturaCentimetros);
        setPesoKilogramos(pesoKilogramos);
    }

    public void setPrimerNombre(String primerNombre) {
        this.primerNombre = primerNombre;
    }

    public String getPrimerNombre() {
        return primerNombre;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getApellido() {
        return apellido;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getSexo() {
        return sexo;
    }

    public void setDiaNacimiento(int diaNacimiento) {
        this.diaNacimiento = diaNacimiento;
    }

    public int getDiaNacimiento() {
        return diaNacimiento;
    }

    public void setMesNacimiento(int mesNacimiento) {
        this.mesNacimiento = mesNacimiento;
    }

    public int getMesNacimiento() {
        return mesNacimiento;
    }

    public void setAnioNacimiento(int anioNacimiento) {
        this.anioNacimiento = anioNacimiento;
    }

    public int getAnioNacimiento() {
        return anioNacimiento;
    }

    public void setAlturaCentimetros(double alturaCentimetros) {
        if (alturaCentimetros > 0) {
            this.alturaCentimetros = alturaCentimetros;
        } else {
            this.alturaCentimetros = 0;
        }
    }

    public double getAlturaCentimetros() {
        return alturaCentimetros;
    }

    public void setPesoKilogramos(double pesoKilogramos) {
        if (pesoKilogramos > 0) {
            this.pesoKilogramos = pesoKilogramos;
        } else {
            this.pesoKilogramos = 0;
        }
    }

    public double getPesoKilogramos() {
        return pesoKilogramos;
    }

    public String mostrarFechaNacimiento() {
        return diaNacimiento + "/" + mesNacimiento + "/" + anioNacimiento;
    }

    public int calcularEdad() {
        LocalDate fechaNacimiento = LocalDate.of(anioNacimiento, mesNacimiento, diaNacimiento);
        LocalDate fechaActual = LocalDate.now();

        return Period.between(fechaNacimiento, fechaActual).getYears();
    }

    public int calcularFrecuenciaCardiacaMaxima() {
        return 220 - calcularEdad();
    }

    public double calcularFrecuenciaCardiacaEsperadaMinima() {
        return calcularFrecuenciaCardiacaMaxima() * 0.50;
    }

    public double calcularFrecuenciaCardiacaEsperadaMaxima() {
        return calcularFrecuenciaCardiacaMaxima() * 0.85;
    }

    public double calcularBMI() {
        double alturaMetros = alturaCentimetros / 100;

        if (alturaMetros > 0) {
            return pesoKilogramos / (alturaMetros * alturaMetros);
        } else {
            return 0;
        }
    }

    public String obtenerCategoriaBMI() {
        double bmi = calcularBMI();

        if (bmi < 18.5) {
            return "Bajo peso";
        } else if (bmi <= 24.9) {
            return "Normal";
        } else if (bmi <= 29.9) {
            return "Sobrepeso";
        } else {
            return "Obeso";
        }
    }
}