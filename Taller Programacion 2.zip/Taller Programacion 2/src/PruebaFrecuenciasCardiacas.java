import java.util.Scanner;

public class PruebaFrecuenciasCardiacas {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);

        System.out.println("CALCULADORA DE FRECUENCIA CARDIACA ESPERADA");
        System.out.println();

        System.out.print("Ingrese el primer nombre: ");
        String primerNombre = entrada.nextLine();

        System.out.print("Ingrese el apellido: ");
        String apellido = entrada.nextLine();

        System.out.print("Ingrese el mes de nacimiento: ");
        int mesNacimiento = entrada.nextInt();

        System.out.print("Ingrese el día de nacimiento: ");
        int diaNacimiento = entrada.nextInt();

        System.out.print("Ingrese el año de nacimiento: ");
        int anioNacimiento = entrada.nextInt();

        FrecuenciasCardiacas persona = new FrecuenciasCardiacas(
                primerNombre,
                apellido,
                mesNacimiento,
                diaNacimiento,
                anioNacimiento
        );

        System.out.println();
        System.out.println("INFORMACIÓN DE LA PERSONA");
        System.out.println("Nombre completo: " + persona.getPrimerNombre() + " " + persona.getApellido());
        System.out.println("Fecha de nacimiento: " + persona.mostrarFechaNacimiento());
        System.out.println("Edad: " + persona.calcularEdad() + " años");
        System.out.println("Frecuencia cardiaca máxima: " + persona.calcularFrecuenciaCardiacaMaxima() + " pulsaciones por minuto");

        System.out.println();
        System.out.println("RANGO DE FRECUENCIA CARDIACA ESPERADA");
        System.out.printf("Frecuencia mínima esperada: %.2f pulsaciones por minuto%n",
                persona.calcularFrecuenciaEsperadaMinima());

        System.out.printf("Frecuencia máxima esperada: %.2f pulsaciones por minuto%n",
                persona.calcularFrecuenciaEsperadaMaxima());

        entrada.close();
    }
}