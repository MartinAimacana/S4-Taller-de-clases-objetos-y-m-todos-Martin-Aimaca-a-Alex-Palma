import javax.swing.JOptionPane;

public class PruebaFactura {

    public static void main(String[] args) {

        String numeroPieza = JOptionPane.showInputDialog("Ingrese el número de pieza:");
        String descripcionPieza = JOptionPane.showInputDialog("Ingrese la descripción de la pieza:");

        int cantidad = Integer.parseInt(
                JOptionPane.showInputDialog("Ingrese la cantidad de artículos:")
        );

        double precioArticulo = Double.parseDouble(
                JOptionPane.showInputDialog("Ingrese el precio por artículo:")
        );

        Factura factura = new Factura(numeroPieza, descripcionPieza, cantidad, precioArticulo);

        String resultado = "DATOS DE LA FACTURA\n\n"
                + "Número de pieza: " + factura.getNumeroPieza() + "\n"
                + "Descripción: " + factura.getDescripcionPieza() + "\n"
                + "Cantidad: " + factura.getCantidad() + "\n"
                + "Precio por artículo: $" + factura.getPrecioArticulo() + "\n"
                + "Monto total de la factura: $" + factura.obtenerMontoFactura();

        JOptionPane.showMessageDialog(null, resultado);
    }
}