import javax.swing.JOptionPane;

public class PruebaEmpleado {

    public static void main(String[] args) {

        String nombre1 = JOptionPane.showInputDialog("Ingrese el primer nombre del empleado 1:");
        String apellido1 = JOptionPane.showInputDialog("Ingrese el apellido paterno del empleado 1:");
        double salario1 = Double.parseDouble(
                JOptionPane.showInputDialog("Ingrese el salario mensual del empleado 1:")
        );

        String nombre2 = JOptionPane.showInputDialog("Ingrese el primer nombre del empleado 2:");
        String apellido2 = JOptionPane.showInputDialog("Ingrese el apellido paterno del empleado 2:");
        double salario2 = Double.parseDouble(
                JOptionPane.showInputDialog("Ingrese el salario mensual del empleado 2:")
        );

        Empleado empleado1 = new Empleado(nombre1, apellido1, salario1);
        Empleado empleado2 = new Empleado(nombre2, apellido2, salario2);

        String resultadoAntes = "SALARIO ANUAL DE CADA EMPLEADO\n\n"
                + empleado1.getPrimerNombre() + " " + empleado1.getApellidoPaterno()
                + "\nSalario mensual: $" + empleado1.getSalarioMensual()
                + "\nSalario anual: $" + empleado1.obtenerSalarioAnual()
                + "\n\n"
                + empleado2.getPrimerNombre() + " " + empleado2.getApellidoPaterno()
                + "\nSalario mensual: $" + empleado2.getSalarioMensual()
                + "\nSalario anual: $" + empleado2.obtenerSalarioAnual();

        JOptionPane.showMessageDialog(null, resultadoAntes);

        empleado1.aplicarAumento();
        empleado2.aplicarAumento();

        String resultadoDespues = "SALARIO ANUAL DESPUÉS DEL AUMENTO DEL 10%\n\n"
                + empleado1.getPrimerNombre() + " " + empleado1.getApellidoPaterno()
                + "\nNuevo salario mensual: $" + empleado1.getSalarioMensual()
                + "\nNuevo salario anual: $" + empleado1.obtenerSalarioAnual()
                + "\n\n"
                + empleado2.getPrimerNombre() + " " + empleado2.getApellidoPaterno()
                + "\nNuevo salario mensual: $" + empleado2.getSalarioMensual()
                + "\nNuevo salario anual: $" + empleado2.obtenerSalarioAnual();

        JOptionPane.showMessageDialog(null, resultadoDespues);
    }
}