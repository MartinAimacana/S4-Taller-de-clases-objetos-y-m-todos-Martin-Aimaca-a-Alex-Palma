import javax.swing.JOptionPane;

public class PruebaPerfilMedico {

    public static void main(String[] args) {

        String primerNombre = JOptionPane.showInputDialog("Ingrese el primer nombre:");
        String apellido = JOptionPane.showInputDialog("Ingrese el apellido:");
        String sexo = JOptionPane.showInputDialog("Ingrese el sexo:");

        int diaNacimiento = Integer.parseInt(
                JOptionPane.showInputDialog("Ingrese el día de nacimiento:")
        );

        int mesNacimiento = Integer.parseInt(
                JOptionPane.showInputDialog("Ingrese el mes de nacimiento:")
        );

        int anioNacimiento = Integer.parseInt(
                JOptionPane.showInputDialog("Ingrese el año de nacimiento:")
        );

        double alturaCentimetros = Double.parseDouble(
                JOptionPane.showInputDialog("Ingrese la altura en centímetros:")
        );

        double pesoKilogramos = Double.parseDouble(
                JOptionPane.showInputDialog("Ingrese el peso en kilogramos:")
        );

        PerfilMedico persona = new PerfilMedico(
                primerNombre,
                apellido,
                sexo,
                diaNacimiento,
                mesNacimiento,
                anioNacimiento,
                alturaCentimetros,
                pesoKilogramos
        );

        String resultado = "PERFIL MÉDICO\n\n"
                + "Nombre completo: " + persona.getPrimerNombre() + " " + persona.getApellido() + "\n"
                + "Sexo: " + persona.getSexo() + "\n"
                + "Fecha de nacimiento: " + persona.mostrarFechaNacimiento() + "\n"
                + "Altura: " + persona.getAlturaCentimetros() + " cm\n"
                + "Peso: " + persona.getPesoKilogramos() + " kg\n\n"

                + "Edad: " + persona.calcularEdad() + " años\n"
                + "BMI: " + String.format("%.2f", persona.calcularBMI()) + "\n"
                + "Categoría BMI: " + persona.obtenerCategoriaBMI() + "\n\n"

                + "Frecuencia cardiaca máxima: "
                + persona.calcularFrecuenciaCardiacaMaxima()
                + " pulsaciones por minuto\n"

                + "Rango de frecuencia cardiaca esperada:\n"
                + "Mínima 50%: "
                + String.format("%.2f", persona.calcularFrecuenciaCardiacaEsperadaMinima())
                + " pulsaciones por minuto\n"

                + "Máxima 85%: "
                + String.format("%.2f", persona.calcularFrecuenciaCardiacaEsperadaMaxima())
                + " pulsaciones por minuto\n\n"

                + "VALORES DE BMI\n"
                + "Bajo peso: menos de 18.5\n"
                + "Normal: entre 18.5 y 24.9\n"
                + "Sobrepeso: entre 25 y 29.9\n"
                + "Obeso: 30 o más";

        JOptionPane.showMessageDialog(null, resultado);
    }
}