import javax.swing.JOptionPane;

public class PruebaFecha {

    public static void main(String[] args) {

        int mes = Integer.parseInt(
                JOptionPane.showInputDialog("Ingrese el mes:")
        );

        int dia = Integer.parseInt(
                JOptionPane.showInputDialog("Ingrese el día:")
        );

        int anio = Integer.parseInt(
                JOptionPane.showInputDialog("Ingrese el año:")
        );

        Fecha fecha = new Fecha(mes, dia, anio);

        String resultado = "DATOS DE LA FECHA\n\n"
                + "Mes: " + fecha.getMes() + "\n"
                + "Día: " + fecha.getDia() + "\n"
                + "Año: " + fecha.getAnio() + "\n\n"
                + "Fecha en formato mes/día/año: " + fecha.mostrarFecha();

        JOptionPane.showMessageDialog(null, resultado);
    }
}